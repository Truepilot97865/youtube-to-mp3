<#
One-click installer for Windows.

Usage (recommended):
  Right-click -> Run with PowerShell, or from an elevated PowerShell:

  .\oneclick_installer.ps1 -ProjectZipUrl 'https://example.com/youtube-to-mp3.zip' -FFmpegZipUrl 'https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip'

What it does:
- Elevates to administrator (UAC) if needed.
- Downloads the project ZIP and extracts it to %ProgramFiles%\YouTubeToMP3 (or to $env:USERPROFILE if ProgramFiles not writable).
- Downloads and extracts FFmpeg, and sets FFMPEG_LOCATION for the system (setx).
- Calls the project's `scripts\setup.ps1` to create the venv and install dependencies.
- Optionally builds the GUI executable (calls the build script) or launches the GUI directly.

Security notes:
- The script downloads and executes code. Share only trusted URLs.
- The recipient must consent to elevation and running the script.
#>

param(
    [Parameter(Mandatory=$true)]
    [string]$ProjectZipUrl,

    [Parameter(Mandatory=$false)]
    [string]$FFmpegZipUrl = "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip",

    [Parameter(Mandatory=$false)]
    [string]$PythonInstallerUrl = "https://www.python.org/ftp/python/3.11.6/python-3.11.6-amd64.exe",

    [switch]$BuildExe
)

function Ensure-RunningAsAdmin {
    $isAdmin = (New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    if (-not $isAdmin) {
        Write-Host "Requesting elevation (UAC)..."
        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = 'powershell'
        $args = @('-ExecutionPolicy','Bypass','-File',"`"$PSCommandPath`"")
        if ($ProjectZipUrl) { $args += '-ProjectZipUrl'; $args += $ProjectZipUrl }
        if ($FFmpegZipUrl) { $args += '-FFmpegZipUrl'; $args += $FFmpegZipUrl }
        if ($BuildExe) { $args += '-BuildExe' }
        $psi.Arguments = $args -join ' '
        $psi.Verb = 'runas'
        try { [System.Diagnostics.Process]::Start($psi) | Out-Null } catch { Write-Error "Elevation cancelled." }
        exit
    }
}

Ensure-RunningAsAdmin

function Download-File($url, $outPath) {
    Write-Host "Downloading $url ..."
    try {
        $wc = New-Object System.Net.WebClient
        $wc.DownloadFile($url, $outPath)
        return $true
    } catch {
        Write-Error "Failed to download $url : $_"
        return $false
    }
}

function Extract-Zip($zipPath, $dest) {
    Write-Host "Extracting $zipPath -> $dest"
    try {
        if (-not (Test-Path $dest)) { New-Item -ItemType Directory -Path $dest | Out-Null }
        Expand-Archive -Force -LiteralPath $zipPath -DestinationPath $dest
        return $true
    } catch {
        Write-Error "Extraction failed: $_"
        return $false
    }
}

# Choose install base
$programFiles = ${env:ProgramFiles}
if ((Test-Path $programFiles) -and (Get-Item $programFiles).Attributes -notmatch 'ReadOnly') {
    $installRoot = Join-Path $programFiles 'YouTubeToMP3'
} else {
    $installRoot = Join-Path $env:USERPROFILE 'YouTubeToMP3'
}

Write-Host "Install root: $installRoot"
New-Item -ItemType Directory -Force -Path $installRoot | Out-Null

$tmp = Join-Path $env:TEMP ([System.Guid]::NewGuid().ToString())
New-Item -ItemType Directory -Force -Path $tmp | Out-Null

# Download project zip
$projZip = Join-Path $tmp 'project.zip'
if (-not (Download-File $ProjectZipUrl $projZip)) { exit 1 }

# Extract project
$projExtract = Join-Path $installRoot 'project'
if (-not (Extract-Zip $projZip $projExtract)) { exit 1 }

# Try to find project root (if zip contains top-level folder)
$children = Get-ChildItem -Path $projExtract -Directory -ErrorAction SilentlyContinue
if ($children.Count -eq 1) { $projectRoot = $children[0].FullName } else { $projectRoot = $projExtract }

Write-Host "Project installed to: $projectRoot"

# Download and extract FFmpeg
$ffZip = Join-Path $tmp 'ffmpeg.zip'
if (-not (Download-File $FFmpegZipUrl $ffZip)) { Write-Warning "FFmpeg download failed; you will need to install FFmpeg manually." } else {
    $ffDir = Join-Path $installRoot 'ffmpeg'
    if (Extract-Zip $ffZip $ffDir) {
        # Attempt to find bin folder
        $ffBin = Get-ChildItem -Path $ffDir -Recurse -Filter 'ffmpeg.exe' -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($ffBin) {
            $ffBinPath = Split-Path $ffBin.FullName -Parent
            Write-Host "Found ffmpeg at $ffBinPath"
            # set system-wide environment variable
            setx FFMPEG_LOCATION $ffBinPath /M | Out-Null
            Write-Host "System environment FFMPEG_LOCATION set to $ffBinPath (new sessions required)."
        } else {
            Write-Warning "Couldn't locate ffmpeg.exe after extraction. Please set FFMPEG_LOCATION manually."
        }
    }
}

# Run project setup script
$setupScript = Join-Path $projectRoot 'scripts\setup.ps1'
function Install-PythonIfMissing {
    # Check if python is available
    $pythonCmd = Get-Command python -ErrorAction SilentlyContinue
    if ($pythonCmd) {
        Write-Host "Python detected: $($pythonCmd.Path)"
        return $true
    }

    if (-not $PythonInstallerUrl) {
        Write-Warning "Python not found and no installer URL provided. Aborting automatic Python install."
        return $false
    }

    $pyInstaller = Join-Path $tmp 'python-installer.exe'
    if (-not (Download-File $PythonInstallerUrl $pyInstaller)) {
        Write-Warning "Failed to download Python installer."
        return $false
    }

    Write-Host "Running Python installer (silent)..."
    try {
        $args = "/quiet InstallAllUsers=1 PrependPath=1 Include_pip=1"
        $p = Start-Process -FilePath $pyInstaller -ArgumentList $args -Wait -PassThru
        if ($p.ExitCode -ne 0) { Write-Warning "Python installer returned exit code $($p.ExitCode)"; return $false }
    } catch {
        Write-Warning "Python installation failed: $_"
        return $false
    }

    # verify
    $pythonCmd = Get-Command python -ErrorAction SilentlyContinue
    if ($pythonCmd) { Write-Host "Python installed: $($pythonCmd.Path)"; return $true }
    Write-Warning "Python install completed but 'python' not on PATH. You may need to login again or set PATH manually."
    return $false
}

if (Test-Path $setupScript) {
    # Ensure Python present (installer may set PATH; we already run as admin)
    Install-PythonIfMissing | Out-Null
    Write-Host "Running project setup..."
    powershell -ExecutionPolicy Bypass -File $setupScript -ffmpegPath $ffBinPath -SetUserEnv
} else {
    Write-Warning "setup.ps1 not found in project; please run the project's setup manually: $projectRoot\scripts\setup.ps1"
}

# Optionally build the exe
if ($BuildExe) {
    $buildScript = Join-Path $projectRoot 'scripts\build_gui.ps1'
    if (Test-Path $buildScript) {
        Write-Host "Building executable... this may take several minutes."
        powershell -ExecutionPolicy Bypass -File $buildScript
    } else {
        Write-Warning "build_gui.ps1 not found in project."
    }
}

Write-Host "Installation finished. Launching application..."
# Try to launch the exe built by script if present, otherwise run the gui.py via the venv python
$exe = Join-Path $installRoot 'dist\YouTubeToMP3.exe'
if (Test-Path $exe) {
    Start-Process -FilePath $exe
} else {
    $venvPython = Join-Path $projectRoot ".venv\Scripts\python.exe"
    $guiScript = Join-Path $projectRoot 'gui.py'
    if (Test-Path $venvPython -and Test-Path $guiScript) {
        Start-Process -FilePath $venvPython -ArgumentList "$guiScript"
    } else {
        Write-Warning "Could not locate executable or venv python to launch the GUI. Start manually in $projectRoot."
    }
}

Write-Host "Temporary files kept at: $tmp (you can remove it)"
