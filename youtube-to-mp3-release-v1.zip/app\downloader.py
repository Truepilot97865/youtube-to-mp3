import os
from yt_dlp import YoutubeDL


class Downloader:
    """Télécharge une URL YouTube en MP3 dans le dossier `downloads/` du projet.

    Utilisation:
        d = Downloader()
        mp3_path = d.download(url)
    """

    def __init__(self, ffmpeg_location: str = None, download_dir: str = None):
        base_dir = os.path.dirname(os.path.abspath(__file__))
        repo_root = os.path.dirname(base_dir)
        self.download_dir = download_dir or os.path.join(repo_root, "downloads")
        os.makedirs(self.download_dir, exist_ok=True)
        self.ffmpeg_location = ffmpeg_location or os.environ.get("FFMPEG_LOCATION")

    def download(self, url: str) -> str:
        if not url:
            raise ValueError("URL vide")

        ydl_opts = {
            "format": "bestaudio/best",
            "outtmpl": os.path.join(self.download_dir, "%(title)s.%(ext)s"),
            "noplaylist": True,
            "quiet": False,
            "no_warnings": False,
            "postprocessors": [{
                "key": "FFmpegExtractAudio",
                "preferredcodec": "mp3",
                "preferredquality": "0",
            }],
        }

        if self.ffmpeg_location:
            ydl_opts["ffmpeg_location"] = self.ffmpeg_location

        with YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=True)
            title = info.get("title", "audio")
            return os.path.join(self.download_dir, f"{title}.mp3")