def validate_url(url):
    # Function to validate the YouTube URL
    import re
    youtube_regex = re.compile(
        r'(https?://)?(www\.)?(youtube\.com/watch\?v=|youtu\.be/)([a-zA-Z0-9_-]{11})')
    return re.match(youtube_regex, url) is not None

def save_file(file_path, content):
    # Function to save content to a file
    with open(file_path, 'wb') as file:
        file.write(content)

def load_file(file_path):
    # Function to load content from a file
    with open(file_path, 'rb') as file:
        return file.read()