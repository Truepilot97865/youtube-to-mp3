# YouTube to MP3 Converter

This project is a simple command-line application that allows users to download YouTube videos and convert them to MP3 format. 

## Features

- Download videos from YouTube using video URLs.
- Convert downloaded videos to MP3 format.
- Simple command-line interface for ease of use.

## Installation

1. Clone the repository:
   ```
   git clone https://github.com/yourusername/youtube-to-mp3.git
   ```
2. Navigate to the project directory:
   ```
   cd youtube-to-mp3
   ```
3. Create and activate a virtual environment, then install dependencies:

   Windows (PowerShell):
   ```powershell
   python -m venv .venv
   .\.venv\Scripts\Activate
   pip install -r requirements.txt
   ```

   Linux / macOS:
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt
   ```

## Usage

To run the application, use the following command:
```
python main.py
```

Notes:
- Ensure FFmpeg is installed and available in your `PATH`, or set the environment variable `FFMPEG_LOCATION` to the folder containing `ffmpeg.exe` (Windows) or `ffmpeg` (Linux/macOS).
- Example PowerShell to set `FFMPEG_LOCATION` temporarily:
```powershell
$env:FFMPEG_LOCATION = 'C:\path\to\ffmpeg\bin'
```

Automatisation (Windows):

Un script PowerShell `scripts/setup.ps1` est fourni pour créer le venv et installer les dépendances. Exemple d'utilisation :

```powershell
.\scripts\setup.ps1 -ffmpegPath 'D:\Convertisseur fait-maison\ffmpeg-9.0.1\bin' -SetUserEnv
```

Le flag `-SetUserEnv` écrira `FFMPEG_LOCATION` dans les variables d'environnement utilisateur (nouvelle session requise).

### Construire une application bureau (Windows)

Un GUI simple est fourni dans `gui.py`. Pour construire un exécutable Windows qui demande les droits administrateur à l'ouverture, utilise PyInstaller via le script `scripts/build_gui.ps1` (nécessite le venv créé précédemment) :

```powershell
Set-Location 'D:\Convertisseur fait-maison\youtube-to-mp3'
.\.venv\Scripts\python.exe scripts\build_gui.ps1
```

Le script installe `pyinstaller` dans le venv, construit `YouTubeToMP3.exe` et copie l'exécutable sur le Bureau. L'exécutable généré utilise l'option `--uac-admin` pour demander l'élévation (UAC) au démarrage.

Remarque : si tu lances `gui.py` directement (script Python), une boîte de dialogue proposera d'augmenter les privilèges avant d'ouvrir l'interface.

You will be prompted to enter a YouTube video URL, and the application will download the video and convert it to MP3 format.

## Contributing

Contributions are welcome! Please open an issue or submit a pull request for any improvements or bug fixes.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.