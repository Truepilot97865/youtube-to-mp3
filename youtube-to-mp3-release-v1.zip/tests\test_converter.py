import unittest
import os
from app.converter import Converter

class TestConverter(unittest.TestCase):

    def setUp(self):
        self.converter = Converter()

    def test_conversion_valid_file(self):
        # Crée un petit fichier WAV silencieux pour tester la conversion
        input_file = "test_audio.wav"
        expected_output_file = "test_audio.mp3"
        # Génère 1 seconde de silence PCM 16-bit mono 44100Hz
        import wave
        import struct

        with wave.open(input_file, 'w') as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(44100)
            frames = b''.join([struct.pack('<h', 0) for _ in range(44100)])
            wf.writeframes(frames)

        try:
            result = self.converter.convert(input_file)
            self.assertTrue(result)
            self.assertTrue(os.path.exists(expected_output_file))
        finally:
            if os.path.exists(input_file):
                os.remove(input_file)
            if os.path.exists(expected_output_file):
                os.remove(expected_output_file)

    def test_conversion_invalid_file(self):
        input_file = "invalid_video.mp4"  # Non-existent file
        result = self.converter.convert(input_file)
        self.assertFalse(result)

    def test_conversion_empty_file(self):
        input_file = ""  # Empty input
        result = self.converter.convert(input_file)
        self.assertFalse(result)

if __name__ == '__main__':
    unittest.main()