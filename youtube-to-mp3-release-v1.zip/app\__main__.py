# Main entry point for the YouTube to MP3 converter application

import sys
from app.downloader import Downloader
from app.converter import Converter

def main():
    if len(sys.argv) != 2:
        print("Usage: python -m youtube-to-mp3 <YouTube_URL>")
        return

    youtube_url = sys.argv[1]
    downloader = Downloader()
    converter = Converter()

    try:
        print("Downloading video...")
        video_file = downloader.download(youtube_url)
        print("Converting to MP3...")
        mp3_file = converter.convert(video_file)
        print(f"Conversion complete: {mp3_file}")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    main()