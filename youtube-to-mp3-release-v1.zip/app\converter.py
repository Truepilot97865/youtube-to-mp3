import os
import shutil
import subprocess


class Converter:
    """Converter simple: convertit un fichier audio/vidéo en MP3.

    API compatible avec les tests : `Converter()` puis `convert(input_file)`.
    La méthode retourne `True` en cas de succès, `False` sinon.
    """

    def __init__(self):
        pass

    def convert(self, input_file: str) -> bool:
        if not input_file:
            return False
        if not os.path.exists(input_file):
            return False

        # Première tentative: utiliser pydub si disponible
        try:
            from pydub import AudioSegment

            audio = AudioSegment.from_file(input_file)
            base, _ = os.path.splitext(input_file)
            output_file = base + ".mp3"
            audio.export(output_file, format="mp3")
            return True
        except Exception:
            # Fallback: utiliser ffmpeg en ligne de commande si présent
            try:
                base, _ = os.path.splitext(input_file)
                output_file = base + ".mp3"
                ffmpeg_cmd = shutil.which("ffmpeg")
                if not ffmpeg_cmd:
                    # possibilité d'une variable d'environnement pointant vers le répertoire bin
                    ffmpeg_location = os.environ.get("FFMPEG_LOCATION")
                    if ffmpeg_location:
                        candidate = os.path.join(ffmpeg_location, "ffmpeg.exe")
                        if os.path.exists(candidate):
                            ffmpeg_cmd = candidate

                if not ffmpeg_cmd:
                    return False

                cmd = [ffmpeg_cmd, "-y", "-i", input_file, "-vn", "-acodec", "libmp3lame", "-q:a", "2", output_file]
                subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                return os.path.exists(output_file)
            except Exception:
                return False

    def extract_audio(self, input_file: str, output_file: str) -> bool:
        # utilitaire explicite si besoin ailleurs
        try:
            audio = AudioSegment.from_file(input_file)
            audio.export(output_file, format="mp3")
            return True
        except Exception:
            return False