# Build script for the GUI app using PyInstaller
# Usage: run from project root in PowerShell

Set-Location (Split-Path -Parent $MyInvocation.MyCommand.Path) | Out-Null
$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path | Split-Path -Parent
Set-Location $projectRoot

$py = Join-Path $projectRoot ".venv\Scripts\python.exe"
if (-not (Test-Path $py)) {
    Write-Error "venv python not found at $py. Create venv first."
    exit 1
}

& $py -m pip install --upgrade pip
& $py -m pip install pyinstaller

# Build one-file Windows GUI executable and request admin on launch (--uac-admin)
& $py -m PyInstaller --onefile --windowed --name "YouTubeToMP3" --uac-admin gui.py

if ($LASTEXITCODE -eq 0) {
    $dist = Join-Path $projectRoot "dist\YouTubeToMP3.exe"
    Write-Host "Build complete. Executable: $dist"
    # Optionally copy to Desktop
    $desktop = [Environment]::GetFolderPath('Desktop')
    Copy-Item $dist -Destination (Join-Path $desktop "YouTubeToMP3.exe") -Force
    Write-Host "Copied executable to Desktop."
} else {
    Write-Error "PyInstaller build failed"
}
