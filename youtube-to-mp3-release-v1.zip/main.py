import os
import sys
from yt_dlp import YoutubeDL

def download_mp3(url: str):
    # Use a stable output folder: user's Downloads/YouTubeToMP3 so EXE builds also write
    home = os.path.expanduser("~")
    download_dir = os.path.join(home, "Downloads", "YouTubeToMP3")
    os.makedirs(download_dir, exist_ok=True)

    ydl_opts = {
        "format": "bestaudio/best",
        "outtmpl": os.path.join(download_dir, "%(title)s.%(ext)s"),
        "noplaylist": True,
        "quiet": False,
        "no_warnings": False,
        "postprocessors": [{
            "key": "FFmpegExtractAudio",
            "preferredcodec": "mp3",
            "preferredquality": "0",
        }],
    }

    # Prefer an explicit environment variable for ffmpeg location (handles spaces)
    ffmpeg_location = os.environ.get("FFMPEG_LOCATION")
    if ffmpeg_location:
        ydl_opts["ffmpeg_location"] = ffmpeg_location

    with YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(url, download=True)
        title = info.get("title", "audio")
        return os.path.join(download_dir, f"{title}.mp3")

if __name__ == "__main__":
    print("Collez l'URL YouTube :")
    url = input("> ").strip()

    if not url:
        print("URL vide.")
        sys.exit(1)

    try:
        result = download_mp3(url)
        print(f"Conversion terminée : {result}")
    except Exception as e:
        print(f"Erreur : {e}")
        sys.exit(1)