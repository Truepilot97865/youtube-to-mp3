# Setup script for Windows (PowerShell)
# Usage: Open PowerShell as normal user and run: .\scripts\setup.ps1

param(
    [string]$ffmpegPath = "",
    [switch]$SetUserEnv
)

$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path | Split-Path -Parent
Write-Host "Project root: $projectRoot"

# Create virtual environment
python -m venv "$projectRoot\.venv"
Write-Host "Virtual environment created at $projectRoot\.venv"

# Activate and install dependencies
$activate = "$projectRoot\.venv\Scripts\Activate"
Write-Host "Installing dependencies using venv python..."
& "$projectRoot\.venv\Scripts\python.exe" -m pip install --upgrade pip
& "$projectRoot\.venv\Scripts\python.exe" -m pip install -r "$projectRoot\requirements.txt"

if ($ffmpegPath -ne "") {
    if (Test-Path $ffmpegPath) {
        Write-Host "FFmpeg path provided: $ffmpegPath"
        if ($SetUserEnv) {
            setx FFMPEG_LOCATION $ffmpegPath
            Write-Host "FFMPEG_LOCATION set as user environment variable (requires new session)."
        } else {
            $env:FFMPEG_LOCATION = $ffmpegPath
            Write-Host "FFMPEG_LOCATION set for current session."
        }
    } else {
        Write-Host "Provided ffmpeg path does not exist: $ffmpegPath" -ForegroundColor Red
    }
} else {
    Write-Host "No ffmpeg path provided. Ensure ffmpeg is in PATH or set FFMPEG_LOCATION."
}

Write-Host "Setup complete. Activate the venv with:"
Write-Host ".\.venv\Scripts\Activate"