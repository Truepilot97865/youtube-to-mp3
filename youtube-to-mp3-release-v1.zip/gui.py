import sys
import os
import threading
import ctypes
import traceback
from tkinter import Tk, Label, Entry, Button, StringVar, messagebox

def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except Exception:
        return False


def relaunch_as_admin():
    # Relaunch the current script/executable with elevation
    try:
        if getattr(sys, 'frozen', False):
            executable = sys.executable
            params = ''
        else:
            executable = sys.executable
            # quote the script path and parameters
            params = ' '.join(['"' + sys.argv[0] + '"'] + ['"' + a + '"' for a in sys.argv[1:]])

        ctypes.windll.shell32.ShellExecuteW(None, 'runas', executable, params, None, 1)
    except Exception:
        traceback.print_exc()
    sys.exit(0)


def run_download(url_var, status_var, button):
    url = url_var.get().strip()
    if not url:
        messagebox.showerror('Erreur', "L'URL est vide")
        return

    def worker():
        try:
            status_var.set('Téléchargement en cours...')
            # import local function
            from main import download_mp3
            output = download_mp3(url)
            status_var.set('Terminé : ' + str(output))
            messagebox.showinfo('Succès', f'Conversion terminée:\n{output}')
            # Open the folder containing the output file for the user
            try:
                folder = os.path.dirname(output)
                if os.path.exists(folder):
                    os.startfile(folder)
            except Exception:
                pass
        except Exception as e:
            status_var.set('Erreur')
            messagebox.showerror('Erreur', f'Une erreur est survenue:\n{e}')
        finally:
            button.config(state='normal')

    button.config(state='disabled')
    threading.Thread(target=worker, daemon=True).start()


def main():
    # Create a hidden root to ask about elevation first
    root = Tk()
    root.withdraw()

    if not is_admin():
        if messagebox.askyesno('Privilèges administrateur', 'Voulez-vous lancer l\'application en mode administrateur ?'):
            relaunch_as_admin()

    # Now build the visible UI
    root.deiconify()
    root.title('YouTube → MP3')
    root.geometry('520x140')

    Label(root, text="Collez l'URL YouTube :").pack(padx=10, pady=(10, 0), anchor='w')
    url_var = StringVar()
    entry = Entry(root, textvariable=url_var, width=80)
    entry.pack(padx=10, pady=(2, 10))
    entry.focus()

    status_var = StringVar()
    status_var.set('Prêt')
    status_label = Label(root, textvariable=status_var)
    status_label.pack(padx=10, pady=(0, 6), anchor='w')

    start_btn = Button(root, text='Télécharger et convertir', command=lambda: run_download(url_var, status_var, start_btn))
    start_btn.pack(padx=10, pady=(0, 10))

    root.mainloop()


if __name__ == '__main__':
    main()
